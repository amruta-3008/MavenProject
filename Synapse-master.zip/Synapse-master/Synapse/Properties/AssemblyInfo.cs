﻿using System.Reflection;

[assembly: AssemblyTitle("Synapse")]
[assembly: AssemblyDescription("Synapse-ModdingFramework")]
[assembly: AssemblyCompany("Synapse-DevTeam")]
[assembly: AssemblyProduct("Synapse")]
[assembly: AssemblyCopyright("Copyright © Synapse-DevTeam 2020")]
[assembly: AssemblyVersion("2.5.0.0")]
[assembly: AssemblyFileVersion("2.5.0.0")]