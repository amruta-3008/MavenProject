﻿namespace Synapse.Api.Enum
{
    public enum AmmoType
    {
        Ammo5,
        Ammo7,
        Ammo9
    }
}
