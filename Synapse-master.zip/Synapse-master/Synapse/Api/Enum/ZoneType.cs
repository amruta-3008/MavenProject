﻿namespace Synapse.Api.Enum
{
   public enum ZoneType
    {
        None,
        LCZ,
        HCZ,
        Entrance,
        Surface,
        Pocket,
    }
}
