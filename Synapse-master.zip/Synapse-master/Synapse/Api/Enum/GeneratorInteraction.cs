﻿namespace Synapse.Api.Enum
{
    public enum GeneratorInteraction
    {
        TabletInjected,
        TabledEjected,
        Unlocked,
        OpenDoor,
        CloseDoor
    }
}
