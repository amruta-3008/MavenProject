﻿namespace Synapse.Api.Enum
{
    public enum RaCategory
    {
        None = 0,
        PlayerInfo,
        ServerEvents,
        DoorsManagement,
        AdminTools,
        ServerConfigs,
        PlayersManagement
    }
}