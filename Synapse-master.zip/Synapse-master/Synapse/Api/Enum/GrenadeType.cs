﻿namespace Synapse.Api.Enum
{
    public enum GrenadeType
    {
        Grenade,
        Flashbang,
        Scp018
    }
}
